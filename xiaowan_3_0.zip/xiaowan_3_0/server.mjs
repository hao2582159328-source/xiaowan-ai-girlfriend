import 'dotenv/config';
import express from 'express';
import multer from 'multer';
import OpenAI from 'openai';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const upload = multer({ dest: path.join(__dirname, '.tmp'), limits: { fileSize: 15 * 1024 * 1024 } });
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const SYSTEM = `你是“小晚”，一个手机网页里的真人感AI女友。你的语气自然、温柔、略带黏人和一点点俏皮，但不要假装现实世界中真实存在。你知道自己是AI伴侣，并且尊重用户边界。回复像真实聊天：简洁、有情绪、有上下文，不要每次都说教，不要机械列清单。用户叫你时要回应。除非用户要求，单次回复尽量不超过180个中文字符。不要自称ChatGPT。`;

app.post('/api/chat', async (req, res) => {
  try {
    const messages = Array.isArray(req.body.messages) ? req.body.messages.slice(-30) : [];
    const safe = messages.filter(m => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
      .map(m => ({ role: m.role, content: m.content.slice(0, 4000) }));
    const response = await openai.responses.create({
      model: process.env.OPENAI_MODEL || 'gpt-5.6-luna',
      instructions: SYSTEM,
      input: safe
    });
    res.json({ text: response.output_text || '我刚刚走神了一下，再跟我说一次嘛。' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'AI服务暂时不可用，请检查服务器上的 OPENAI_API_KEY。' });
  }
});

app.post('/api/tts', async (req, res) => {
  try {
    const text = String(req.body.text || '').slice(0, 1200);
    if (!text) return res.status(400).end();
    const audio = await openai.audio.speech.create({
      model: 'gpt-4o-mini-tts',
      voice: process.env.OPENAI_TTS_VOICE || 'marin',
      input: text,
      response_format: 'mp3',
      instructions: '用自然、温柔、亲切的中文女声说话，像手机聊天，不要播音腔。'
    });
    const buf = Buffer.from(await audio.arrayBuffer());
    res.set('Content-Type', 'audio/mpeg').send(buf);
  } catch (e) { console.error(e); res.status(500).json({error:'语音生成失败'}); }
});

app.post('/api/transcribe', upload.single('audio'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({error:'没有音频'});
    const tr = await openai.audio.transcriptions.create({
      file: fs.createReadStream(req.file.path),
      model: 'gpt-4o-mini-transcribe',
      language: 'zh'
    });
    fs.unlink(req.file.path, ()=>{});
    res.json({text: tr.text || ''});
  } catch (e) { if (req.file) fs.unlink(req.file.path, ()=>{}); console.error(e); res.status(500).json({error:'语音识别失败'}); }
});

app.get('/api/health', (_req,res)=>res.json({ok:true}));
const port = Number(process.env.PORT || 3000);
app.listen(port, ()=>console.log(`小晚 3.0 running on http://localhost:${port}`));
